"""Small authored low-poly pieces shared by linked Blender mesh datablocks."""
import math


def box(size, taper=1):
    a,b,c=(s/2 for s in size)
    v=[(sx*a*(taper if sz>0 else 1),sy*b*(taper if sz>0 else 1),sz*c)
       for sx,sy,sz in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),
                        (-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
    return v,[(0,3,2,1),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,6,7)]


def rings(profiles,n=8):
    v=[(cx+rx*math.sin((i+.5)*2*math.pi/n),cy+ry*math.cos((i+.5)*2*math.pi/n),z)
       for z,rx,ry,cx,cy in profiles for i in range(n)]
    f=[tuple(range(n))]
    for j in range(len(profiles)-1):
        for i in range(n):
            a,b=j*n+i,j*n+(i+1)%n
            f.append((a+n,b+n,b,a))
    f.append(tuple(reversed(range((len(profiles)-1)*n,len(v)))))
    return v,f


def spike(base,tip):
    return base+[tip],[(0,3,2,1),(0,1,4),(1,2,4),(2,3,4),(3,0,4)]


def definitions():
    p={}
    p['head']=rings([(1.48,.21,.20,0,0),(1.56,.34,.27,0,0),(1.88,.39,.29,0,0),
                     (2.08,.31,.26,0,-.02),(2.12,.17,.16,0,-.04)])
    p['torso']=rings([(.72,.31,.21,0,0),(1.20,.34,.215,0,0),(1.43,.29,.19,0,0)])
    p['torso_female']=rings([(.72,.28,.19,0,0),(1.0,.255,.18,0,0),(1.24,.31,.21,0,0),(1.42,.26,.18,0,0)])
    p['neck']=box((.22,.22,.18))
    p['trousers']=rings([(0,.145,.17,0,.005),(.29,.12,.15,0,0),(.59,.14,.17,0,0)],6)
    p['shorts']=rings([(0,.14,.17,0,0),(.28,.15,.18,0,0)],6)
    p['bare_leg']=rings([(0,.09,.10,0,0),(.50,.105,.12,0,0)],6)
    p['sleeve_long']=rings([(0,.12,.145,.07,0),(.4,.13,.17,0,0)],6)
    p['sleeve_short']=rings([(0,.13,.16,.03,0),(.23,.13,.17,0,0)],6)
    p['forearm']=rings([(0,.08,.10,.025,.015),(.30,.095,.12,0,0)],6)
    p['bare_arm']=rings([(0,.08,.10,.065,.015),(.52,.10,.12,0,0)],6)
    p['hand']=rings([(-.08,.075,.08,0,0),(-.02,.12,.11,0,0),(.10,.10,.10,-.02,-.01)],6)
    p['sole']=box((.31,.43,.10))
    p['shoe']=box((.29,.40,.12),.8)
    p['ear']=rings([(-.075,.055,.065,0,0),(.08,.07,.07,0,0)],6)
    p['skirt']=rings([(.49,.40,.26,0,0),(.78,.29,.20,0,0)])
    p['long_skirt']=rings([(.20,.43,.28,0,0),(.78,.29,.20,0,0)])
    p['coat_skirt']=rings([(.53,.39,.24,0,-.025),(.83,.35,.23,0,-.025)])
    p['belt']=box((.62,.43,.075))
    p['hair_cap']=rings([(1.89,.395,.32,0,-.04),(2.08,.35,.29,0,-.055),(2.20,.15,.14,0,-.05)])
    p['flat_hair']=rings([(1.90,.39,.30,0,-.035),(2.17,.36,.28,0,-.035),(2.19,.31,.25,0,-.035)])
    p['hair_back']=rings([(1.32,.30,.13,0,-.22),(1.65,.40,.16,0,-.20),(2.02,.36,.19,0,-.14)])
    p['hair_side']=box((.15,.35,.42),.8)
    p['bob_back']=rings([(1.51,.30,.12,0,-.21),(1.78,.42,.18,0,-.16),(2.07,.34,.18,0,-.10)])
    p['bun']=rings([(-.12,.11,.11,0,0),(.02,.18,.16,0,0),(.14,.11,.11,0,0)],8)
    # This envelope contains the generic scalp above its brim. The old cap
    # intersected the scalp at the crown, exposing black wedges in native VI.
    p['cap']=rings([(1.92,.43,.38,0,-.04),(2.15,.39,.34,0,-.04),(2.25,.17,.17,0,-.04)])
    p['brim']=box((.57,.37,.045),.85)
    p['hood']=rings([(1.48,.35,.23,0,-.06),(1.8,.44,.32,0,-.06),(2.10,.39,.30,0,-.07),(2.20,.25,.21,0,-.07)])
    p['hood_ear']=box((.20,.20,.20),.9)
    p['backpack']=box((.48,.25,.54),.9)
    xs=[-.31,-.16,.16,.31];ys=[.202,.273,.273,.202]
    p['face']=([(x,y,h) for h in (1.56,1.89) for x,y in zip(xs,ys)],
               [(4,5,1,0),(5,6,2,1),(6,7,3,2)])
    p['nose']=spike([(-.035,.275,1.68),(.035,.275,1.68),(.03,.275,1.79),(-.03,.275,1.79)],(0,.34,1.70))
    p['shadow']=([( .45*math.cos(i*math.pi/4),.32*math.sin(i*math.pi/4),.018) for i in range(8)], [tuple(range(8))])
    return p
