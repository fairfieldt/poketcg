"""Validate links and measure actual mesh reuse in the opened cast.blend."""
import bpy
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
for library in bpy.data.libraries:
    assert Path(bpy.path.abspath(library.filepath)).exists(),library.filepath
instances=[o for o in bpy.context.scene.objects if o.instance_type=='COLLECTION']
assert len(instances)==39,len(instances)
parts=[]
unique=set()
for instance in instances:
    for obj in instance.instance_collection.objects:
        data=obj.data
        if data.library and Path(data.library.filepath).name=='parts.blend':
            parts.append(obj);unique.add(data.name)
assert len(parts)==802,len(parts)
assert len(unique)<=33,len(unique)
report=dict(canonical_models=39,npc_ids=115,appearances=42,shared_library_meshes=33,
            used_shared_meshes=len(unique),linked_part_instances=len(parts),textures=11,
            shared_mesh_names=sorted(unique),all_libraries_present=True)
(ROOT/'review/sharing.json').write_text(json.dumps(report,indent=2)+'\n')
print('BLENDER_VALID',len(instances),'unique models,',len(parts),'linked instances of',len(unique),'used shared meshes')
